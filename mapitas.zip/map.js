const createLineStringBetweenTwoPoints = (pointsArray, stroke, color) => {
    const finalColor = color || '#000000';
}